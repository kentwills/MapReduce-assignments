import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.util.Iterator;

import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.WritableUtils;

import com.google.common.collect.Iterators;

import edu.umd.cloud9.io.pair.PairOfInts;

public class PostingsList implements Iterable<PairOfInts> {
  private final DataInputStream data;
  private final int df;

  public PostingsList(BytesWritable w) throws IOException {
    ByteArrayInputStream bytesIn = new ByteArrayInputStream(w.getBytes());
    this.data = new DataInputStream(bytesIn);
    this.df = WritableUtils.readVInt(data);
  }

  private void reset() throws IOException {
    data.reset();
    WritableUtils.readVInt(data);
  }

  public int getDf() {
    return df;
  }

  @Override
  public Iterator<PairOfInts> iterator() {
    try {
      reset();
    } catch (IOException e1) {
      e1.printStackTrace();
    }

    return new Iterator<PairOfInts>() {
      private int cnt = 0;
      private int prev;

      @Override
      public boolean hasNext() {
        return cnt < df;
      }

      @Override
      public PairOfInts next() {
        try {
          int docno = cnt == 0 ? WritableUtils.readVInt(data) : prev + WritableUtils.readVInt(data);
          int tf = WritableUtils.readVInt(data);
          prev = docno;
          cnt++;
          return new PairOfInts(docno, tf);
        } catch (IOException e) {
          return null;
        } 
      }

      @Override
      public void remove() {
        throw new UnsupportedOperationException();
      }
    };
  }

  @Override
  public String toString() {
    return String.format("(%d, %s)", getDf(), Iterators.toString(iterator()));
  }
}
