
**Pairs implementation:** The pairs implementation consists of two MapReduce jobs. The first job is a modified version of word count, where we compute all the unigram counts `c(x)`. These counts are stored on HDFS and serve as "side data" for the second MapReduce job.

The second MapReduce job counts all pairs `(x, y)` using the basic pairs pattern. The additional "trick" is to load in the unigram counts in as side data: this is accomplished in the `setup` method of the reducer, where we open up the unigram counts file from HDFS and load it completely into memory. As we're processing joint `(x, y)` counts in the reducer, we lookup the unigram counts and compute the PMI.

Note, as we discussed in class, it is generally safe to assume that the vocabulary will fit into memory.

**Stripes implementation:** The stripes implementation is very similar to the pairs implementation. It is also two MapReduce jobs, except in the second MapReduce job we use the stripes pattern to keep track of the joint counts. We load in the unigram counts side data in the same way.

To run the pairs implementation:

```
$ etc/hadoop-cluster.sh PairsPMI -input bible+shakes.nopunc.gz -output lintool-pairs -numReducers 5
```

To run the stripes implementation:

```
$ etc/hadoop-cluster.sh StripesPMI -input bible+shakes.nopunc.gz -output lintool-stripes -numReducers 5
```

**Running times:**

With combiners:

```
Job1             21s
Job2-pairs      159s
Job2-stripes     60s
```

Without combiners:

```
Job1             21s
Job2-pairs      170s
Job2-stripes     60s
```

Interestingly, for the first job and for the stripes implementation, combiners don't make a difference in terms of performance (for a dataset of this size in the VM).


**Question 3.** How many distinct PMI pairs did you extract?

```
$ hadoop fs -cat 'lintool-pairs/part-*' | wc
233518  700554 5804511
```

That's 233,518 pairs, or 116,759 *unique* pairs.


**Question 4.** What's the pair (x, y) with the highest PMI? Write a sentence or two to 
explain what it is and why it has such a high PMI.

```
$ hadoop fs -cat 'lintool-pairs/part-*' | sort -k3 -g -r | head -6
(shadrach, meshach)        4.0475945
(shadrach, abednego)       4.0475945
(meshach, shadrach)        4.0475945
(meshach, abednego)        4.0475945
(abednego, shadrach)       4.0475945
(abednego, meshach)        4.0475945
```

Note that I used base 10 log. In base *e*, the top value would be 9.31993.

Shadrach, Meshach, and Abednego are people recorded in the book of Daniel; see article in [Wikipedia](http://en.wikipedia.org/wiki/Shadrach,_Meshach,_and_Abednego).

Also check in the stripes implementation:

```
$ hadoop fs -cat 'lintool-stripes/part*' | grep -P 'shadrach\t'
shadrach	{and=0.49459642, of=0.4929964, meshach=4.0475945, abednego=4.0475945, the=0.4890747}
```

**Question 5.** What are the three words that have the highest PMI with "cloud" and "love"? And what are the PMI values?

For "cloud":

```
$ hadoop fs -cat 'lintool-pairs/part-*' | grep '(cloud,' | sort -k3 -g -r | head -3
(cloud, tabernacle)  1.8036358
(cloud, glory)	     1.4761128
(cloud, fire)	     1.4051478
```

These are base 10 log values. In base *e*, they would be:

```
(cloud, tabernacle)  4.153025
(cloud, glory)       3.3988752
(cloud, fire)        3.2354724 
```

For "love":

```
$ hadoop fs -cat 'lintool-pairs/part-*' | grep '(love,' | sort -k3 -g -r | head -3
(love, hate)    1.1185408
(love, hermia)	0.88118005
(love, commandments)	0.8423343
```

The values in base *e* are:

```
(love, hate)          2.5755355
(love, hermia)        2.0289917
(love, commandments)  1.9395468
```
