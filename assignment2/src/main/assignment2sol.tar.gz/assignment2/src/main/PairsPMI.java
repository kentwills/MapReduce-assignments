import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.LineReader;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.google.common.collect.Sets;

import edu.umd.cloud9.io.pair.PairOfStrings;
import edu.umd.cloud9.util.map.HMapKI;

public class PairsPMI extends Configured implements Tool {
  private static final Logger LOG = Logger.getLogger(PairsPMI.class);

  private static final int LINES = 156215;
  private static final String TMP_PATH = "unigram-counts/";

  private static class MyMapper extends Mapper<LongWritable, Text, PairOfStrings, FloatWritable> {
    private static final PairOfStrings PAIR = new PairOfStrings();
    private static final FloatWritable ONE = new FloatWritable(1);

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException,
        InterruptedException {
      String line = ((Text) value).toString();
      StringTokenizer itr = new StringTokenizer(line);
      Set<String> set = Sets.newHashSet();
      while (itr.hasMoreTokens()) {
        set.add(itr.nextToken());
      }

      String[] words = new String[set.size()];
      words = set.toArray(words);
      for (int i = 0; i < words.length; i++) {
        for (int j = 0; j < words.length; j++) {
          if (i == j) {
            continue;
          }
          PAIR.set(words[i], words[j]);
          context.write(PAIR, ONE);
        }
      }
    }
  }

  private static class MyCombiner extends
      Reducer<PairOfStrings, FloatWritable, PairOfStrings, FloatWritable> {
    private final static FloatWritable COUNT = new FloatWritable();

    @Override
    public void reduce(PairOfStrings key, Iterable<FloatWritable> values, Context context)
        throws IOException, InterruptedException {
      Iterator<FloatWritable> iter = values.iterator();
      int sum = 0;
      while (iter.hasNext()) {
        sum += iter.next().get();
      }

      COUNT.set((float) sum);
      context.write(key, COUNT);
    }
  }

  private static class MyReducer extends
      Reducer<PairOfStrings, FloatWritable, PairOfStrings, FloatWritable> {
    private final static FloatWritable PMI = new FloatWritable();
    private final HMapKI<String> dictionary = new HMapKI<String>();

    @Override
    public void setup(Context context) throws IOException {
      // Load in side data from HDFS.
      FileSystem fs = FileSystem.get(context.getConfiguration());
      LineReader reader = new LineReader(fs.open(new Path(TMP_PATH + "part-r-00000")));
      Text text = new Text();
      while (reader.readLine(text) > 0) {
        String[] arr = text.toString().split("\\t");
        dictionary.put(arr[0], Integer.parseInt(arr[1]));
      }
      reader.close();
    }

    @Override
    public void reduce(PairOfStrings key, Iterable<FloatWritable> values, Context context)
        throws IOException, InterruptedException {
      Iterator<FloatWritable> iter = values.iterator();
      int sum = 0;
      while (iter.hasNext()) {
        sum += iter.next().get();
      }

      if (sum > 9) {
        float pmi = (float) Math.log10((float) sum / LINES)
            - (float) Math.log10((float) dictionary.get(key.getLeftElement()) / LINES)
            - (float) Math.log10((float) dictionary.get(key.getRightElement()) / LINES);
        PMI.set(pmi);
        context.write(key, PMI);
      }
    }
  }

  protected static class MyPartitioner extends Partitioner<PairOfStrings, FloatWritable> {
    @Override
    public int getPartition(PairOfStrings key, FloatWritable value, int numReduceTasks) {
      return (key.getLeftElement().hashCode() & Integer.MAX_VALUE) % numReduceTasks;
    }
  }

  /**
   * Creates an instance of this tool.
   */
  public PairsPMI() {
  }

  private static final String INPUT = "input";
  private static final String OUTPUT = "output";
  private static final String NUM_REDUCERS = "numReducers";
  private static final String NO_COMBINER = "noCombiner";

  /**
   * Runs this tool.
   */
  @SuppressWarnings({ "static-access" })
  public int run(String[] args) throws Exception {
    Options options = new Options();

    options.addOption(new Option(NO_COMBINER, "don't use combiner"));

    options.addOption(OptionBuilder.withArgName("path").hasArg().withDescription("input path")
        .create(INPUT));
    options.addOption(OptionBuilder.withArgName("path").hasArg().withDescription("output path")
        .create(OUTPUT));
    options.addOption(OptionBuilder.withArgName("num").hasArg()
        .withDescription("number of reducers").create(NUM_REDUCERS));

    CommandLine cmdline;
    CommandLineParser parser = new GnuParser();

    try {
      cmdline = parser.parse(options, args);
    } catch (ParseException exp) {
      System.err.println("Error parsing command line: " + exp.getMessage());
      return -1;
    }

    if (!cmdline.hasOption(INPUT) || !cmdline.hasOption(OUTPUT)) {
      System.out.println("args: " + Arrays.toString(args));
      HelpFormatter formatter = new HelpFormatter();
      formatter.setWidth(120);
      formatter.printHelp(this.getClass().getName(), options);
      ToolRunner.printGenericCommandUsage(System.out);
      return -1;
    }

    String inputPath = cmdline.getOptionValue(INPUT);
    String outputPath = cmdline.getOptionValue(OUTPUT);
    String tmpPath = TMP_PATH;
    int reduceTasks = cmdline.hasOption(NUM_REDUCERS) ?
        Integer.parseInt(cmdline.getOptionValue(NUM_REDUCERS)) : 1;

    LOG.info("Tool: " + CountFrequency.class.getSimpleName());
    LOG.info(" - input path: " + inputPath);
    LOG.info(" - output path: " + tmpPath);

    Configuration conf = getConf();
    Job job1 = Job.getInstance(conf);
    job1.setJobName(CountFrequency.class.getSimpleName());
    job1.setJarByClass(CountFrequency.class);

    job1.setNumReduceTasks(1);

    FileInputFormat.setInputPaths(job1, new Path(inputPath));
    FileOutputFormat.setOutputPath(job1, new Path(tmpPath));

    job1.setOutputKeyClass(Text.class);
    job1.setOutputValueClass(IntWritable.class);

    job1.setMapperClass(CountFrequency.CountFrequencyMapper.class);
    if (!cmdline.hasOption(NO_COMBINER)) {
      job1.setCombinerClass(CountFrequency.CountFrequencyReducer.class);
    }
    job1.setReducerClass(CountFrequency.CountFrequencyReducer.class);

    // Delete the tmp directory if it exists already.
    Path tmpDir = new Path(tmpPath);
    FileSystem.get(conf).delete(tmpDir, true);

    long startTime = System.currentTimeMillis();
    job1.waitForCompletion(true);
    LOG.info("Job Finished in " + (System.currentTimeMillis() - startTime) / 1000.0 + " seconds");

    LOG.info("Tool: " + PairsPMI.class.getSimpleName());
    LOG.info(" - input path: " + inputPath);
    LOG.info(" - output path: " + outputPath);
    LOG.info(" - number of reducers: " + reduceTasks);

    Job job2 = Job.getInstance(conf);
    job2.setJobName(PairsPMI.class.getSimpleName());
    job2.setJarByClass(PairsPMI.class);

    job2.setNumReduceTasks(reduceTasks);

    FileInputFormat.setInputPaths(job2, new Path(inputPath));
    FileOutputFormat.setOutputPath(job2, new Path(outputPath));

    job2.setMapOutputKeyClass(PairOfStrings.class);
    job2.setMapOutputValueClass(FloatWritable.class);
    job2.setOutputKeyClass(PairOfStrings.class);
    job2.setOutputValueClass(FloatWritable.class);

    job2.setMapperClass(MyMapper.class);
    if (!cmdline.hasOption(NO_COMBINER)) {
      job2.setCombinerClass(MyCombiner.class);
    }
    job2.setReducerClass(MyReducer.class);
    job2.setPartitionerClass(MyPartitioner.class);

    // Delete the output directory if it exists already.
    Path outputDir = new Path(outputPath);
    FileSystem.get(conf).delete(outputDir, true);

    startTime = System.currentTimeMillis();
    job2.waitForCompletion(true);
    LOG.info("Job Finished in " + (System.currentTimeMillis() - startTime) / 1000.0 + " seconds");

    return 0;
  }

  /**
   * Dispatches command-line arguments to the tool via the {@code ToolRunner}.
   */
  public static void main(String[] args) throws Exception {
    ToolRunner.run(new PairsPMI(), args);
  }
}