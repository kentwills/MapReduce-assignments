import java.io.IOException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.LineReader;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import com.google.common.collect.Sets;

import edu.umd.cloud9.io.map.HMapSFW;
import edu.umd.cloud9.util.map.HMapKI;
import edu.umd.cloud9.util.map.MapKF;

public class StripesPMI extends Configured implements Tool {
  private static final Logger LOG = Logger.getLogger(StripesPMI.class);

  private static final int LINES = 156215;
  private static final String TMP_PATH = "unigram-counts/";

  private static class MyMapper extends Mapper<LongWritable, Text, Text, HMapSFW> {
    private static final HMapSFW MAP = new HMapSFW();
    private static final Text KEY = new Text();

    @Override
    public void map(LongWritable key, Text value, Context context) throws IOException,
        InterruptedException {
      String line = ((Text) value).toString();
      StringTokenizer itr = new StringTokenizer(line);
      Set<String> set = Sets.newHashSet();
      while (itr.hasMoreTokens()) {
        set.add(itr.nextToken());
      }

      String[] words = new String[set.size()];
      words = set.toArray(words);
      for (int i = 0; i < words.length; i++) {
        MAP.clear();
        for (int j = 0; j < words.length; j++) {
          if (i == j) {
            continue;
          }
          MAP.put(words[j], 1.0f);
        }
        KEY.set(words[i]);
        context.write(KEY, MAP);
      }
    }
  }

  private static class MyCombiner extends Reducer<Text, HMapSFW, Text, HMapSFW> {
    @Override
    public void reduce(Text key, Iterable<HMapSFW> values, Context context)
        throws IOException, InterruptedException {
      Iterator<HMapSFW> iter = values.iterator();
      HMapSFW map = new HMapSFW();

      while (iter.hasNext()) {
        map.plus(iter.next());
      }

      context.write(key, map);
    }
  }

  private static class MyReducer extends Reducer<Text, HMapSFW, Text, HMapSFW> {
    private final HMapKI<String> dictionary = new HMapKI<String>();

    @Override
    public void setup(Context context) throws IOException {
      // Load in side data from HDFS.
      FileSystem fs = FileSystem.get(context.getConfiguration());
      LineReader reader = new LineReader(fs.open(new Path(TMP_PATH + "part-r-00000")));
      Text text = new Text();
      while (reader.readLine(text) > 0) {
        String[] arr = text.toString().split("\\t");
        dictionary.put(arr[0], Integer.parseInt(arr[1]));
      }
      reader.close();
    }

    @Override
    public void reduce(Text key, Iterable<HMapSFW> values, Context context)
        throws IOException, InterruptedException {
      Iterator<HMapSFW> iter = values.iterator();
      HMapSFW map = new HMapSFW();

      while (iter.hasNext()) {
        map.plus(iter.next());
      }

      HMapSFW pmiMap = new HMapSFW();
      for (MapKF.Entry<String> e : map.entrySet()) {
        if ( e.getValue() > 9) {
          float pmi = (float) Math.log10((float) e.getValue() / LINES)
              - (float) Math.log10((float) dictionary.get(key.toString()) / LINES)
              - (float) Math.log10((float) dictionary.get(e.getKey()) / LINES);
          pmiMap.put(e.getKey(), pmi);
        }
      }
      context.write(key, pmiMap);
    }
  }

  /**
   * Creates an instance of this tool.
   */
  public StripesPMI() {}

  private static final String INPUT = "input";
  private static final String OUTPUT = "output";
  private static final String NUM_REDUCERS = "numReducers";
  private static final String NO_COMBINER = "noCombiner";

  /**
   * Runs this tool.
   */
  @SuppressWarnings({ "static-access" })
  public int run(String[] args) throws Exception {
    Options options = new Options();

    options.addOption(new Option(NO_COMBINER, "don't use combiner"));

    options.addOption(OptionBuilder.withArgName("path").hasArg()
        .withDescription("input path").create(INPUT));
    options.addOption(OptionBuilder.withArgName("path").hasArg()
        .withDescription("output path").create(OUTPUT));
    options.addOption(OptionBuilder.withArgName("num").hasArg()
        .withDescription("number of reducers").create(NUM_REDUCERS));

    CommandLine cmdline;
    CommandLineParser parser = new GnuParser();

    try {
      cmdline = parser.parse(options, args);
    } catch (ParseException exp) {
      System.err.println("Error parsing command line: " + exp.getMessage());
      return -1;
    }

    if (!cmdline.hasOption(INPUT) || !cmdline.hasOption(OUTPUT)) {
      System.out.println("args: " + Arrays.toString(args));
      HelpFormatter formatter = new HelpFormatter();
      formatter.setWidth(120);
      formatter.printHelp(this.getClass().getName(), options);
      ToolRunner.printGenericCommandUsage(System.out);
      return -1;
    }

    String inputPath = cmdline.getOptionValue(INPUT);
    String outputPath = cmdline.getOptionValue(OUTPUT);
    String tmpPath = TMP_PATH;
    int reduceTasks = cmdline.hasOption(NUM_REDUCERS) ?
        Integer.parseInt(cmdline.getOptionValue(NUM_REDUCERS)) : 1;

    LOG.info("Tool: " + CountFrequency.class.getSimpleName());
    LOG.info(" - input path: " + inputPath);
    LOG.info(" - output path: " + tmpPath);

    Configuration conf = getConf();
    Job job1 = Job.getInstance(conf);
    job1.setJobName(CountFrequency.class.getSimpleName());
    job1.setJarByClass(CountFrequency.class);

    job1.setNumReduceTasks(1);

    FileInputFormat.setInputPaths(job1, new Path(inputPath));
    FileOutputFormat.setOutputPath(job1, new Path(tmpPath));

    job1.setOutputKeyClass(Text.class);
    job1.setOutputValueClass(IntWritable.class);

    job1.setMapperClass(CountFrequency.CountFrequencyMapper.class);
    if (!cmdline.hasOption(NO_COMBINER)) {
      job1.setCombinerClass(CountFrequency.CountFrequencyReducer.class);
    }
    job1.setReducerClass(CountFrequency.CountFrequencyReducer.class);

    // Delete the tmp directory if it exists already.
    Path tmpDir = new Path(tmpPath);
    FileSystem.get(conf).delete(tmpDir, true);

    long startTime = System.currentTimeMillis();
    job1.waitForCompletion(true);
    LOG.info("Job Finished in " + (System.currentTimeMillis() - startTime) / 1000.0 + " seconds");

    LOG.info("Tool: " + StripesPMI.class.getSimpleName());
    LOG.info(" - input path: " + inputPath);
    LOG.info(" - output path: " + outputPath);
    LOG.info(" - number of reducers: " + reduceTasks);

    Job job2 = Job.getInstance(conf);
    job2.setJobName(StripesPMI.class.getSimpleName());
    job2.setJarByClass(StripesPMI.class);

    job2.setNumReduceTasks(reduceTasks);

    FileInputFormat.setInputPaths(job2, new Path(inputPath));
    FileOutputFormat.setOutputPath(job2, new Path(outputPath));

    job2.setMapOutputKeyClass(Text.class);
    job2.setMapOutputValueClass(HMapSFW.class);
    job2.setOutputKeyClass(Text.class);
    job2.setOutputValueClass(HMapSFW.class);

    job2.setMapperClass(MyMapper.class);
    if (!cmdline.hasOption(NO_COMBINER)) {
      job2.setCombinerClass(MyCombiner.class);
    }
    job2.setReducerClass(MyReducer.class);

    // Delete the output directory if it exists already.
    Path outputDir = new Path(outputPath);
    FileSystem.get(conf).delete(outputDir, true);

    startTime = System.currentTimeMillis();
    job2.waitForCompletion(true);
    LOG.info("Job Finished in " + (System.currentTimeMillis() - startTime) / 1000.0 + " seconds");

    return 0;
  }

  /**
   * Dispatches command-line arguments to the tool via the {@code ToolRunner}.
   */
  public static void main(String[] args) throws Exception {
    ToolRunner.run(new StripesPMI(), args);
  }
}